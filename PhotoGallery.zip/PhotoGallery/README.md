# Silence blank project
This is an empty Silence project.