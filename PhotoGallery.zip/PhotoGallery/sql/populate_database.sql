INSERT INTO Users
VALUES
	(1, 'John', 'Doe', '+01 (541) 754-3010', 'john.doe@gallery.com', 'john', 'jhon', './images/bf2.jpg'),
	(2, 'Jane', 'Smith', '+34 678 387 155', 'jane.smith@gallery.com', 'jane', 'pbkdf2:sha256:150000$v4wgnaXC$b87f5daf437119c21ec712462f4b193b6fada27f485e36502c5cf4553a01f640', '/images/bf3.jpg'),
	(3, 'Jaime', 'Raynaud', '642046182', 'jairaysan@alum.us.es', 'jairaysan', 'pbkdf2:sha256:150000$sR7fGA4J$4dab7ea1f13d7337bd7da4aaf356c707bfe567b6efa8ac30d633e4192e11f8e2', './images/carpimcho.jpg'),
	(4, 'Victor', 'Raynaud', '642046181', 'tokete@alum.us.es', 'tokete', 'pbkdf2:sha256:150000$sR7fGA4J$4dab7ea1f13d7337bd7da4aaf356c707bfe567b6efa8ac30d633e4192e11f8e2', './images/jerbo.jpg'),
	(5, 'Juan', 'Jose', '642046180', 'kilil@alum.us.es', 'kilil', 'pbkdf2:sha256:150000$sR7fGA4J$4dab7ea1f13d7337bd7da4aaf356c707bfe567b6efa8ac30d633e4192e11f8e2', './images/beluga.jpg');

-- Password = username

INSERT INTO Categories
VALUES
	(1, 'Deportes'),
	(2, 'Sin categoria'),
	(3, 'Amigos'),
	(4, 'Viajes'),
	(5, 'Ciudad'),
	(6, 'Naturaleza'),
	(7, 'Animales');

INSERT INTO Photos
VALUES
	(1, 'Tortilla', 'A typical Spanish tortilla. With onion, of course.', '2021-06-2 13:37:01', 'https://cdn1.cocina-familiar.com/recetas/thumb/tortilla-de-patata-con-cebolla.jpg', 'Public',4.00, 1, 'Comida', 'Sin categoria'),
	(2, 'Samoyed', 'A very fluffy dog', '2021-06-2 13:37:01', 'https://www.dogsnsw.org.au/media/img/BrowseAllBreed/Samoyed-.jpg', 'Public',5.00, 2, 'Animales', 'Sin categoria'),
	(3, 'Sleepy cat', 'A drawing of a cat about to sleep', '2021-06-2 13:37:01', 'https://pbs.twimg.com/media/EZ4Z2QDUYAANA-Z?format=png', 'Public',3.00, 1, 'Animales', 'Sin categoria'),
	(4, 'Seville', 'The beautiful city of Seville, Spain', '2021-06-2 13:37:01', 'https://urbansevilla.es/wp-content/uploads/2019/03/urban-sevilla-foto-ciudad.jpg', 'Public',1.00, 2, 'Ciudad', 'Sin categoria'),
	(5, 'Carpimcho', 'Un carpimcho', '2021-06-2 13:37:01', './images/carpimcho.jpg', 'Public',1.50, 3, 'Animales', 'Naturaleza'),
	(6, 'Beluga', 'Un belugon', '2021-06-2 13:37:01', './images/beluga.jpg', 'Public',5.00, 5, 'Animales', 'Sin categoria'),
	(7, 'Jerbo', 'Un jerbo', '2021-06-2 13:37:01', './images/jerbo.jpg', 'Public',4.50, 4, 'Animales', 'Sin categoria'),
	(8, 'Canguro', 'Un canguro', '2021-06-2 13:37:01', './images/kangaroo.jpg', 'Public',5.00, 3, 'Naturaleza', 'Sin categoria'),
	(9, 'tyson', 'Un foton', '2021-06-2 13:37:01', './images/tyson.jpg', 'Public',4.00, 1, 'Deportes', 'Amigos'),
	(10, 'bf3', 'Un foton', '2021-06-2 13:37:01', './images/bf3.jpg', 'Public',5.00, 2, 'Naturaleza', 'Sin categoria'),
	(11, 'Un bulldog', 'Un bulldog frances', '2021-06-2 13:37:01', './images/bulldogf.jpg', 'Public',4.00, 3, 'Animales', 'Sin categoria'),
	(12, 'Nueva york', 'Una ciudad', '2021-06-2 13:37:01', './images/newyork.jpg', 'Public',4.00, 4, 'Ciudad', 'Viajes'),
	(13, 'doge', 'Un perrete', '2021-06-2 13:37:01', './images/shibainu.jpg', 'Public',4.00, 5, 'Animales', 'Sin categoria');




INSERT INTO Comments
VALUES
	(1, 'Me gusta la foto!', 1, 1, '2021-06-2 13:37:01'),
	(2,'Preciosa', 1, 2, '2021-06-2 13:37:01'),
	(3,'jajaja', 1, 3, '2021-06-2 13:37:01'),
	(4, 'Que bonito',2, 4, '2021-06-2 13:37:01'),
	(5,'chulada', 1, 5, '2021-06-2 13:37:01'),
	(6,'muy guay', 2, 6, '2021-06-2 13:37:01'),
	(7,'increible', 3, 7, '2021-06-2 13:37:01'),
	(8,'apabullante', 4, 8, '2021-06-2 13:37:01'),
	(9,'majestuoso', 5, 9, '2021-06-2 13:37:01'),
	(10,'bonito', 1, 10, '2021-06-2 13:37:01'),
	(11,'meh', 2, 11, '2021-06-2 13:37:01'),
	(12,'hola', 3, 12, '2021-06-2 13:37:01'),
	(13,'mmm', 4, 13, '2021-06-2 13:37:01'),
	(14,'jaja', 5, 13, '2021-06-2 13:37:01'),
	(15,'lol', 1, 13, '2021-06-2 13:37:01'),
	(16,'xd', 5, 11, '2021-06-2 13:37:01');

INSERT INTO UserPhotos
VALUES
	(1, 1, 1),
	(2, 1, 2),
	(3, 1, 3),
	(4, 2, 4);

INSERT INTO UserFollowers
VALUES
	(1, 1, 2),
	(2, 2, 1),
	(3, 3, 4),
	(4, 3, 5),
	(5, 3, 1),
	(6, 3, 2),
	(7, 1, 3),
	(8, 2, 3),
	(9, 4, 3),
	(10, 5, 3);

INSERT INTO InvalidWords
VALUES
	('autolesion'),
	('suicidio');

INSERT INTO Valorations
VALUES
	(1, 1, 1, 4.00, '2021-06-2 13:37:01'),
	(2, 1, 2, 5.00, '2021-06-2 13:37:01'),
	(3, 2, 3, 3.00, '2021-06-2 13:37:01'),
	(4, 2, 4, 1.00, '2021-06-2 13:37:01'),
	(5, 3, 5, 1.50, '2021-06-2 13:37:01'),
	(6, 3, 6, 5.00, '2021-06-2 13:37:01'),
	(7, 4, 7, 4.50, '2021-06-2 13:37:01'),
	(8, 4, 8, 5.00, '2021-06-2 13:37:01'),
	(9, 5, 9, 4.00, '2021-06-2 13:37:01'),
	(10, 5, 10, 5.00, '2021-06-2 13:37:01'),
	(11, 5, 11, 4.00, '2021-06-2 13:37:01'),
	(12, 5, 12, 4.00, '2021-06-2 13:37:01'),
	(13, 5, 13, 4.00, '2021-06-2 13:37:01'),
	(14, 4, 1, 4.00, '2021-06-2 13:37:01'),
	(15, 5, 1, 4.00, '2021-06-2 13:37:01');

