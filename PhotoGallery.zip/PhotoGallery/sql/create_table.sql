DROP TABLE IF EXISTS Valorations;
DROP TABLE IF EXISTS InvalidWords;
DROP TABLE IF EXISTS UserFollowers;
DROP TABLE IF EXISTS UserPhotos;
DROP TABLE IF EXISTS Commentaries;
DROP TABLE IF EXISTS Photos;
DROP TABLE IF EXISTS Categories;
DROP TABLE IF EXISTS Users;

CREATE TABLE Users (
	userId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	firstName VARCHAR(128) NOT NULL,
	lastName VARCHAR(128) NOT NULL,
	telephone VARCHAR(32) NOT NULL,
	email VARCHAR(128) UNIQUE NOT NULL,
	username VARCHAR(64) UNIQUE NOT NULL,
	password VARCHAR(256) NOT NULL,
	avatarUrl VARCHAR(512)
);

CREATE TABLE Categories (
	categoryId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	category VARCHAR(56) NOT NULL
);

CREATE TABLE Photos (
	photoId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	title VARCHAR(128) NOT NULL,
	description VARCHAR(512),
	date DATETIME DEFAULT CURRENT_TIMESTAMP,
	url VARCHAR(512) NOT NULL,
	visibility VARCHAR(16) NOT NULL,
	valoration DECIMAL(4,2) DEFAULT 0.00,
	userId INT NOT NULL,
	category VARCHAR(56),
	category2 VARCHAR(56),
	FOREIGN KEY (userId) REFERENCES Users (userId),

	CONSTRAINT InvalidVisibility CHECK (visibility in ('Public', 'Private'))
);

CREATE TABLE Comments (
	commentId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	comment VARCHAR(512) NOT NULL,
	userId INT NOT NULL,
	photoId INT NOT NULL,
	date DATETIME DEFAULT CURRENT_TIMESTAMP,
	FOREIGN KEY (userId) REFERENCES Users (userId),
	FOREIGN KEY (photoId) REFERENCES Photos (photoId)
);

CREATE TABLE UserPhotos (
	userPhotoId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	userId INT NOT NULL,
	photoId INT NOT NULL,
	FOREIGN KEY (userId) REFERENCES Users (userId),
	FOREIGN KEY (photoId) REFERENCES Photos (photoId),
	UNIQUE (userId, photoId)
);

CREATE TABLE UserFollowers (
	userFollowerId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	userId INT NOT NULL,
	user2Id INT NOT NULL,
	FOREIGN KEY (userId) REFERENCES Users (userId),
	FOREIGN KEY (user2Id) REFERENCES Users (userId),
	UNIQUE (userId, user2Id),
	CONSTRAINT invalidFollower CHECK (userId != user2Id)
);

CREATE TABLE InvalidWords (
	word VARCHAR(56) NOT NULL PRIMARY KEY
);

CREATE TABLE Valorations (
	valorationId INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	userId INT NOT NULL,
	photoId INT NOT NULL,
	valoration DECIMAL(4,2),
	date DATETIME DEFAULT CURRENT_TIMESTAMP,
	FOREIGN KEY (userId) REFERENCES Users (userId),
	FOREIGN KEY (photoId) REFERENCES Photos (photoId),
	UNIQUE (userId, photoId)
);





