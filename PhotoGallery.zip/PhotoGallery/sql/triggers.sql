DELIMITER //
CREATE OR REPLACE TRIGGER InvalidTitle
	BEFORE INSERT ON Photos
	FOR EACH ROW 
	BEGIN 
		if (NEW.title LIKE "%suicidio%" OR NEW.title LIKE "%autolesion%" OR NEW.title LIKE "%bullying%") then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You cannot use an invalid word in title';
		END if;
	END //
DELIMITER ;




DELIMITER //
CREATE OR REPLACE TRIGGER InvalidDescription
	BEFORE INSERT ON Photos
	FOR EACH ROW 
	BEGIN 
		if (NEW.description LIKE "%suicidio%" OR NEW.description LIKE "%autolesion%" OR NEW.description LIKE "%bullying%") then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You cannot use an invalid word in description';
		END if;
	END //
DELIMITER ;


DELIMITER //
CREATE OR REPLACE TRIGGER InvalidActuDescription
	BEFORE UPDATE ON Photos
	FOR EACH ROW 
	BEGIN 
		if (NEW.description LIKE "%suicidio%" OR NEW.description LIKE "%autolesion%" OR NEW.description LIKE "%bullying%") then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You cannot use an invalid word in description';
		END if;
	END //
DELIMITER ;




DELIMITER //
CREATE OR REPLACE TRIGGER InvalidComment
	BEFORE INSERT ON Comments
	FOR EACH ROW 
	BEGIN 
		if (NEW.comment LIKE "%suicidio%" OR NEW.comment LIKE "%autolesion%" OR NEW.comment LIKE "%bullying%") then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You cannot use an invalid word in comment';
		END if;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER limitedPhotos
	BEFORE INSERT ON Photos
	FOR EACH ROW 
	BEGIN 
		DECLARE numUserPhotos INT;
		SET numUserPhotos = (SELECT COUNT(*) FROM Photos WHERE userId = NEW.userId);
		if (numUserPhotos>=50) then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You have reached the maximum amount of photos per user (50)';
		END if;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER invalidAutoFollow
	BEFORE INSERT ON UserFollowers
	FOR EACH ROW 
	BEGIN 
		if (NEW.userId = NEW.user2Id) then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You cannot autofollow yourself';
		END if;
	END //
DELIMITER ;


DELIMITER //
CREATE OR REPLACE TRIGGER invalidFollow
	BEFORE INSERT ON UserFollowers
	FOR EACH ROW 
	BEGIN 
        DECLARE numErrors INT;
		SET numErrors = (SELECT COUNT(*) FROM UserFollowers WHERE (userId = NEW.userId AND user2Id = NEW.user2Id));
		if (numErrors>0) then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You already follow this user';
		END if;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER invalidValoration
	BEFORE INSERT ON Valorations
	FOR EACH ROW 
	BEGIN 
        DECLARE numErrors INT;
		SET numErrors = (SELECT COUNT(*) FROM Valorations WHERE (userId = NEW.userId AND photoId = NEW.photoId));
		if (numErrors>0) then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You have already rate this photo';
		END if;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER invalidUser
	BEFORE INSERT ON Users
	FOR EACH ROW 
	BEGIN 
        DECLARE numErrors INT;
		SET numErrors = (SELECT COUNT(*) FROM Users WHERE (username = NEW.username OR email = NEW.email));
		if (numErrors>0) then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'Theres already a user with the same email or username';
		END if;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER invalidPhotoCategory
	BEFORE INSERT ON Photos
	FOR EACH ROW 
	BEGIN 
		if (NEW.category NOT IN (SELECT category FROM Categories) OR NEW.category2 NOT IN (SELECT category FROM Categories)) 
		then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'That category doesn´t exists, you have to create it first';
		END if;
	END //
DELIMITER ; 

DELIMITER //
CREATE OR REPLACE TRIGGER invalidCategory
	BEFORE INSERT ON Categories
	FOR EACH ROW 
	BEGIN 
        DECLARE numErrors INT;
		SET numErrors = (SELECT COUNT(*) FROM Categories WHERE (category = NEW.category));
		if (numErrors>0) then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'That category already exists';
		END if;
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE FUNCTION avgRate(photoId INT) RETURNS DOUBLE 
	BEGIN 
		RETURN (SELECT AVG(VALUE)
			FROM Valorations
			WHERE Valorations.photoId = photoId);
	END //
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER unchangablePhoto
	BEFORE UPDATE ON Photos
	FOR EACH ROW 
	BEGIN 
		DECLARE numComments INT;
		SET numComments = (SELECT COUNT(*) FROM Comments WHERE (photoId = NEW.photoId));
		if (numComments>0 AND NEW.visibility = 'Private') then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'A photo with comments cannot become Private';
		END if;
	END //
DELIMITER ;



DELIMITER //
CREATE TRIGGER deletePhoto 
BEFORE DELETE on Photos
FOR EACH ROW
	BEGIN
		DECLARE numComments INT;
		SET numComments = (SELECT COUNT(*) FROM Comments WHERE (photoId = OLD.photoId));
		if (numComments>0) 
			then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A photo with comments cannot be deleted';
		END if;
	END
//
DELIMITER ;

DELIMITER //
CREATE OR REPLACE TRIGGER invalidCommentPrivate
	BEFORE INSERT ON Comments
	FOR EACH ROW 
	BEGIN
		DECLARE numE INT;
		SET numE = (SELECT COUNT(*) FROM Photos WHERE (photoId = NEW.photoId AND visibility = 'Private'));
		if (numE>0) 
		then  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
			'You cannot comment a private photo';
		END if;
	END //
DELIMITER ;
