"use strict";

import { photosAPI } from "/js/api/photos.js";
import { messageRenderer } from "/js/renderers/messages.js";
import { sessionManager } from "/js/utils/session.js";
import { authAPI } from "/js/api/auth.js";
import { usersAPI } from "/js/api/users.js";
import { profileRenderer } from "/js/renderers/profile_renderer.js"
import { galleryRenderer } from "/js/renderers/gallery.js"

let urlParams = new URLSearchParams(window.location.search);
let userId = urlParams.get("userId");

function main() {
    let userContainer = document.getElementById("profile-text");

    usersAPI.getById(userId)
        .then(users => {
            let userDetails = profileRenderer.asCard(users[0]);
            userContainer.appendChild(userDetails);
        })
        .catch(error => {
            messageRenderer.showErrorMessage(error)
        });

    usersAPI.getUserPhotos(userId)
        .then(photos => {
            let gallery = galleryRenderer.asCardGallery(photos);
            userContainer.appendChild(gallery);
        })
        .catch(error => {
            messageRenderer.showErrorMessage(error)
        });
        if (sessionManager.isLogged() && sessionManager.getLoggedId()!==userId) {
            let followBtn = document.querySelector("#button-follow");
            followBtn.onclick = handleFollow;
            let unfollowBtn = document.querySelector("#button-unfollow");
            unfollowBtn.onclick = handleUnfollow;
        }
        
}

function handleFollow(event) {
    let user1Id = sessionManager.getLoggedUser().userId;
    let user2Id = urlParams.get("userId");
    usersAPI.userFollows(user1Id, user2Id)
        .then(data => window.location.href = "profile.html?userId="+user2Id)
        .catch(error => messageRenderer.showErrorMessage(error));

}

function handleUnfollow(event) {
    let user1Id = sessionManager.getLoggedUser().userId;
    let user2Id = urlParams.get("userId");
    usersAPI.userUnfollows(user1Id, user2Id)
        .then(data => window.location.href = "profile.html?userId="+user2Id)
        .catch(error => messageRenderer.showErrorMessage(error));

}

document.addEventListener("DOMContentLoaded", main)
