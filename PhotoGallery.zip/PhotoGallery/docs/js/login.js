"use strict";

import { sessionManager } from "/js/utils/session.js";
import { authAPI } from "/js/api/auth.js";
import { photoRenderer } from "/js/renderers/photo.js";
import { messageRenderer } from "/js/renderers/messages.js";
function main() {
    let regForm = document.getElementById("registerForm");
    regForm.onsubmit = handleSubmitRegister;

}
function handleSubmitRegister(event) {
    event.preventDefault();
    let form = event.target;
    let formData = new FormData(form);

    sendLogin(formData);
}

function sendLogin(formData) {
    authAPI.login(formData)
        .then(loginData => 
            {
                let sessionToken = loginData.sessionToken;
                let loggedUser = loginData.user;
                sessionManager.login (sessionToken , loggedUser) ;
                window.location.href = "index.html";
            })
        .catch(error => messageRenderer.showErrorMessage(error));
}

document.addEventListener("DOMContentLoaded", main)