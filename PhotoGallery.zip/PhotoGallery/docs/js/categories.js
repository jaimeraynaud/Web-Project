"use strict";

import { messageRenderer } from "/js/renderers/messages.js";
import { photosAPI } from "/js/api/photos.js";
import { parseHTML } from "/js/utils/parseHTML.js";
import { sessionManager } from "/js/utils/session.js";


let urlParams = new URLSearchParams(window.location.search);
let userId = urlParams.get("userId");

function main() {
    let container = document.querySelector("li.list-group-item");
    photosAPI.get_allCategories()
        .then(categories => {
            for (let category of categories) {
                if(category.category != "Sin categoria"){
                    let html = `<h5> <a href="photos_category.html?categoryId=${category.categoryId}"> ${category.category}</a></h5>`;
                    let card = parseHTML(html);
                    container.appendChild(card);
                }
                
            }
        })
        .catch(error => messageRenderer.showErrorMessage(error));
    if (sessionManager.isLogged()) { //Un usuario no logeado no podrá añadir una categoria
        let categoryForm = document.getElementById("categoryForm");
        categoryForm.onsubmit = handleSubmitCategory;
    }
}
function handleSubmitCategory(event) {
    event.preventDefault();
    let form = event.target;
    let formData = new FormData(form);
    
    photosAPI.createCategory(formData)
        .then(data => window.location.href = "categories.html")
        .catch(error => messageRenderer.showErrorMessage(error));
    
}

document.addEventListener("DOMContentLoaded", main)
