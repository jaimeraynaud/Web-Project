"use strict";

import { parseHTML } from "/js/utils/parseHTML.js";
import { usersAPI } from "/js/api/users.js";

const profileRenderer = {
    asCard: function (user) {
        let html = `<div class="row py-5 px-4">
                        <div class="col-md-5 mx-auto">
                            <div class="bg-white shadow rounded overflow-hidden">
                                <div class="px-4 pt-0 pb-4 cover">
                                    <div class="media align-items-end profile-head">
                                        <div class="profile mr-3"><img src="${user.avatarUrl}" alt="..." width="130" class="rounded mb-2 img-thumbnail"><a href="edit_profile.html" class="btn btn-outline-dark btn-sm btn-block">Edit profile</a></div>
                                        <div class="media-body mb-5 text-white">
                                            <h4 class="mt-0 mb-0">${user.username}</h4>
                                            <p class="small mb-4"> <i class="fas fa-map-marker-alt mr-2"></i></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="px-4 py-3"></div>
                                <div class="px-4 py-3">
                                        <div class="p-4 rounded shadow-sm bg-light">
                                            <a href="followers.html?userId=${user.userId}" class="text-muted"><i class="fas fa-user mr-1"></i>Followers</a>
                                            <a href="following.html?userId=${user.userId}" class="text-muted"> <i class="fas fa-user mr-1"></i>Following</a>
                                        </div>
                                </div>
                                <div class="px-4 py-3">
                                        <h5 class="mb-0">About</h5>
                                        <div class="p-4 rounded shadow-sm bg-light">
                                            <p class="font-italic mb-0">Name: ${user.firstName}</p>
                                            <p class="font-italic mb-0">Surname: ${user.lastName}</p>
                                            <p class="font-italic mb-0">Telephone: ${user.telephone}</p>
                                            <p class="font-italic mb-0">Email: ${user.email}</p>
                                        </div>
                                </div>
                                <div class="py-4 px-4">
                                    <div class="d-flex align-items-center justify-content-between mb-3">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`
        let card = parseHTML(html);
        return card;
    },

};

export {profileRenderer}