" use_strict ";

import { BASE_URL, requestOptions } from "./common.js";

const photosAPI = {
    getAll: function () {
        return new Promise(function(resolve, reject) {
            axios
            .get(`${BASE_URL}/photos`, requestOptions)
            .then(response => resolve(response.data))
            .catch(error => reject(error.response.data.message));
        });
    },
    getById: function (photoId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/photos/${photoId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    getValorationById: function (photoId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/valorations/${photoId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    create: function (formData) {
        return new Promise(function (resolve, reject) {
            axios
                .post(`${BASE_URL}/photos`, formData, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },
    update: function (photoId, formData) {
        return new Promise(function (resolve, reject) {
            axios
                .put(`${BASE_URL}/photos/${photoId}`, formData,
                    requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },
    delete: function (photoId) {
        return new Promise(function (resolve, reject) {
            axios
                .delete(`${BASE_URL}/photos/${photoId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    createCategory: function (formData) {
        return new Promise(function (resolve, reject) {
            axios
                .post(`${BASE_URL}/categories`, formData, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    get_allCategories: function () {
        return new Promise(function(resolve, reject) {
            axios
            .get(`${BASE_URL}/categories`, requestOptions)
            .then(response => resolve(response.data))
            .catch(error => reject(error.response.data.message));
        });
    },

    get_by_category: function (categoryId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/categories/${categoryId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    get_comments_byId: function (photoId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/comments/${photoId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    createComment: function (formData) {
        return new Promise(function (resolve, reject) {
            axios
                .post(`${BASE_URL}/comments`, formData, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    getAllFriends: function (userId) {
        return new Promise(function(resolve, reject) {
            axios
            .get(`${BASE_URL}/photosFriends/${userId}`, requestOptions)
            .then(response => resolve(response.data))
            .catch(error => reject(error.response.data.message));
        });
    },

    getBestRatedPhotos: function () {
        return new Promise(function(resolve, reject) {
            axios
            .get(`${BASE_URL}/photosBestRated`, requestOptions)
            .then(response => resolve(response.data))
            .catch(error => reject(error.response.data.message));
        });
    },

    getMostCommentedPhotos: function () {
        return new Promise(function(resolve, reject) {
            axios
            .get(`${BASE_URL}/photosMostCommented`, requestOptions)
            .then(response => resolve(response.data))
            .catch(error => reject(error.response.data.message));
        });
    },

    getCategoriesMostFrequent: function () {
        return new Promise(function(resolve, reject) {
            axios
            .get(`${BASE_URL}/categoriesMostFrequent`, requestOptions)
            .then(response => resolve(response.data))
            .catch(error => reject(error.response.data.message));
        });
    },


};

export { photosAPI };