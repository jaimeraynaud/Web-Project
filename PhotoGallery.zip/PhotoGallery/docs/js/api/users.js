"use_strict";
import { BASE_URL, requestOptions } from './common.js';

const usersAPI = {
    getById: function (userId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/users/${userId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    getUserPhotos: function (userId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/userPhotos/${userId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    getUserFollowers: function (userId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/userFollowers/${userId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    getUserFollowing: function (userId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/userFollowing/${userId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    userFollows: function (userId, user2Id) {
        let data = {
            userId: userId,
            user2Id: user2Id
        };
        return new Promise(function (resolve, reject) {
            axios
                .post(`${BASE_URL}/userFollows`, data, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    userUnfollows: function (userId, user2Id) {
        return new Promise(function (resolve, reject) {
           axios
                .delete(`${BASE_URL}/userUnfollows/${userId}/${user2Id}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    userValorations: function (userId) {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/userValorations/${userId}`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    userValorates: function (formData) {
        return new Promise(function (resolve, reject) {
            axios
                .post(`${BASE_URL}/userValorates`, formData, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    mostFollowedUsers: function () {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/mostFollowedUsers`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },

    bestRankedUsers: function () {
        return new Promise(function (resolve, reject) {
            axios
                .get(`${BASE_URL}/bestRankedUsers`, requestOptions)
                .then(response => resolve(response.data))
                .catch(error => reject(error.response.data.message));
        });
    },
};
    export { usersAPI };