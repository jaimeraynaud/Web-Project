"use strict";
import { galleryRenderer } from "/js/renderers/gallery.js";
import { photosAPI } from "/js/api/photos.js";
import { messageRenderer } from "/js/renderers/messages.js";

let urlParams = new URLSearchParams(window.location.search);
let categoryId = urlParams.get("categoryId");

function main() {
    let container = document.querySelector("div.container");
    photosAPI.get_by_category(categoryId)
        .then(photos => {
            let gallery = galleryRenderer.asCardGallery(photos);
            container.appendChild(gallery);
        })
        .catch(error => messageRenderer.showErrorMessage(error));
}

document.addEventListener("DOMContentLoaded", main)