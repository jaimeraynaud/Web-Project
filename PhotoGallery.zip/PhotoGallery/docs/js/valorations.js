"use strict";

import { messageRenderer } from "/js/renderers/messages.js";
import { usersAPI } from "/js/api/users.js";
import { parseHTML } from "/js/utils/parseHTML.js";
import { sessionManager } from "/js/utils/session.js";


let userId = sessionManager.getLoggedUser().userId;

function main() {
    let container = document.querySelector("li.list-group-item");
    usersAPI.userValorations(userId)

        .then(valorations => {
            for (let valoration of valorations) {
                
                let html = `<h5><a href= "photo_details.html?photoId=${valoration.photoId}" class= "user-link">Photo: ${valoration.photoId}, Valoration: ${valoration.valoration}, ${valoration.date}</a></h5>`;
                let card = parseHTML(html);
                container.appendChild(card);
            }
        })
        .catch(error => messageRenderer.showErrorMessage(error));
}

document.addEventListener("DOMContentLoaded", main)