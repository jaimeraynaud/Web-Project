"use strict";

import { messageRenderer } from "/js/renderers/messages.js";
import { usersAPI } from "/js/api/users.js";
import { parseHTML } from "/js/utils/parseHTML.js";
import { sessionManager } from "/js/utils/session.js";


let urlParams = new URLSearchParams(window.location.search);
let userId = urlParams.get("userId");
function main() {
    let container = document.querySelector("li.list-group-item");
    usersAPI.getUserFollowing(userId)
        .then(following => {
            for (let follower of following) {
                let html = `<h5><a href= "profile.html?userId=${follower.userId}" class= "user-link"> ${follower.username}</a></h5>`;
                let card = parseHTML(html);
                container.appendChild(card);
            }
        })
        .catch(error => messageRenderer.showErrorMessage(error));
}

document.addEventListener("DOMContentLoaded", main)
