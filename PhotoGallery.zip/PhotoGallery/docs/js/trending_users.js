"use strict";
import { galleryRenderer } from "/js/renderers/gallery.js";
import { photosAPI } from "/js/api/photos.js";
import { usersAPI } from "/js/api/users.js";
import { messageRenderer } from "/js/renderers/messages.js";
import { photoRenderer } from "/js/renderers/photo.js";
import { parseHTML } from "/js/utils/parseHTML.js";



function main() {

    let containerFollowed = document.getElementById("containerFollowed");
            usersAPI.mostFollowedUsers()
                .then(infos => {
                    for(let info of infos ){
                        console.log(info);
                        let html = `<p> <a href= "profile.html?userId=${info.user2Id}" class= "photo-link">User ${info.user2Id}</a>, Followers ${info.num}</p>`;
                        let cat = parseHTML(html);
                        containerFollowed.appendChild(cat);
                    }
                    
                })
                .catch(error => messageRenderer.showErrorMessage(error));

                let containerRanked = document.getElementById("containerRanked");
                usersAPI.bestRankedUsers()
                    .then(infos => {
                        for(let info of infos ){
                            console.log(info);
                            let html = `<p> <a href= "profile.html?userId=${info.userId}" class= "photo-link">User ${info.userId}</a>, Rank: ${info.mean}</p>`;
                            let cat = parseHTML(html);
                            containerRanked.appendChild(cat);
                        }
                        
                    })
                    .catch(error => messageRenderer.showErrorMessage(error));

            
}

document.addEventListener("DOMContentLoaded", main)
