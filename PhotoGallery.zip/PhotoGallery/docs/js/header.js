" use strict ";

import { sessionManager } from "/js/utils/session.js";

function main() {
    showUser();
    if (sessionManager.isLogged()) {
        acesProfile();
    }
    addLogoutHandler();
    hideHeaderOptions();

}
function acesProfile(){
    let headerProfile = document.getElementById("navbar-profile");
    headerProfile.href = "profile.html?userId="+sessionManager.getLoggedUser().userId;
}

function showUser() {
    let title = document.getElementById("navbar-title");
    let text;
    if (sessionManager.isLogged()) {
        let username = sessionManager.getLoggedUser().username;
        text = "Hi, @" + username;
    } else {
        text = "Anonymous";
    }
    title.textContent = text;
}

function addLogoutHandler() {
    let logoutButton = document.getElementById("navbar-logout");
    logoutButton.addEventListener("click", function () {
        sessionManager.logout();
        window.location.href = "index.html";
    });
}

function hideHeaderOptions() {
    let headerProfile = document.getElementById("navbar-profile");
    let headerRegister = document.getElementById("navbar-register");
    let headerLogin = document.getElementById("navbar-login");
    let headerLogout = document.getElementById("navbar-logout");
    let headerRecent = document.getElementById("navbar-recent");
    let headerUpload = document.getElementById("navbar-upload");
    let headerValorations = document.getElementById("navbar-valorations");
    let headerFriend = document.getElementById("navbar-friend");
    if (sessionManager.isLogged()) {
        headerRegister.style.display = "none";
        headerLogin.style.display = "none";
    } else {
        headerProfile.style.display = "none";
        headerFriend.style.display = "none";
        headerLogout.style.display = "none";
        headerValorations.style.display = "none";
        headerUpload.style.display = "none";

    }
}

document.addEventListener("DOMContentLoaded", main);
