"use strict";
import { galleryRenderer } from "/js/renderers/gallery.js";
import { photosAPI } from "/js/api/photos.js";
import { messageRenderer } from "/js/renderers/messages.js";
import { photoRenderer } from "/js/renderers/photo.js";
import { parseHTML } from "/js/utils/parseHTML.js";



function main() {
    let container = document.getElementById("containerRated");
    photosAPI.getBestRatedPhotos()
        .then(photos => {
            let gallery = galleryRenderer.asCardGallery(photos);
            container.appendChild(gallery);
        })
        .catch(error => messageRenderer.showErrorMessage(error));

        let containerCommented = document.getElementById("containerCommented");
        photosAPI.getMostCommentedPhotos()
            .then(ids => {
                for(let id of ids ){
                    console.log(id);
                    let html = `<p> <a href= "photo_details.html?photoId=${id.photoId}" class= "photo-link"> Photo ${id.photoId}</a></p>`;
                    let photito = parseHTML(html);
                    containerCommented.appendChild(photito);
                }
                
            })
            .catch(error => messageRenderer.showErrorMessage(error));

            let containerCategories = document.getElementById("containerCategories");
            photosAPI.getCategoriesMostFrequent()
                .then(infos => {
                    for(let info of infos ){
                        console.log(info);
                        let html = `<p> <a href= "categories.html" class= "photo-link">${info.category}: ${info.c}</a></p>`;
                        let cat = parseHTML(html);
                        containerCategories.appendChild(cat);
                    }
                    
                })
                .catch(error => messageRenderer.showErrorMessage(error));
}

document.addEventListener("DOMContentLoaded", main)
