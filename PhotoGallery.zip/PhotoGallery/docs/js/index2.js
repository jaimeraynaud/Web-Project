"use strict";
import { galleryRenderer } from "/js/renderers/gallery.js";
import { photosAPI } from "/js/api/photos.js";
import { messageRenderer } from "/js/renderers/messages.js";
import { sessionManager } from "/js/utils/session.js";


function main() {
    let container = document.querySelector("div.container");
    let userId = sessionManager.getLoggedUser().userId;
    console.log(userId);
    photosAPI.getAllFriends(userId)
        .then(photos => {
            let gallery = galleryRenderer.asCardGallery(photos);
            container.appendChild(gallery);
        })
        .catch(error => messageRenderer.showErrorMessage(error));
}

document.addEventListener("DOMContentLoaded", main)
