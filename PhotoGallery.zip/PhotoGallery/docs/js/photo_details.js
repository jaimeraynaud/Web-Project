"use strict";

import { parseHTML } from "/js/utils/parseHTML.js";

import { photosAPI } from "/js/api/photos.js";
import { photoRenderer } from "/js/renderers/photo.js";
import { messageRenderer } from "/js/renderers/messages.js";
import { sessionManager } from "/js/utils/session.js";
import { profileRenderer } from "/js/renderers/profile_renderer.js";
import { usersAPI } from "/js/api/users.js";


let urlParams = new URLSearchParams(window.location.search);
let photoId = urlParams.get("photoId");

let userId = sessionManager.getLoggedId();

function main() {

    let photoContainer = document.querySelector("#photo-details-column");

    photosAPI.getById(photoId)
        .then(photos => {
            let photoDetails = photoRenderer.asDetails(photos[0]);
            photoContainer.appendChild(photoDetails);
            if(sessionManager.getLoggedId() == photos.userId){ //Hay que corregirlooooooooooo
                let actions_col1 = document.getElementById("photo-buttons-column");
                actions_col1.style.display = "none";
            }
        })
        .catch(error => {
            messageRenderer.showErrorMessage(error)
        });

    let valorationContainer = document.getElementById("actual-valoration");
    photosAPI.getValorationById(photoId)
        .then(valoration => {
            console.log(valoration);
            let html = `<h5>${valoration[0].jaja}</h5>`;
            let valorationValue = parseHTML(html);
            valorationContainer.appendChild(valorationValue);
        })
        .catch(error => {
            messageRenderer.showErrorMessage(error)
        });
        

    let deleteBtn = document.querySelector("#button-delete");
    deleteBtn.onclick = handleDelete;

    let editBtn = document.querySelector("#button-edit");
    editBtn.onclick = handleEdit;

    hideActionButtons();

    let valorationForm = document.getElementById("valorationForm");
    let userIdForm = document.getElementById("userId-input");
    userIdForm.value = userId;
    let photoIdForm = document.getElementById("photoId-input");
    photoIdForm.value = photoId;

    valorationForm.onsubmit = handleSubmitValoration;
    
 
    let commentForm = document.getElementById("commentForm");
    let userIdcommentForm = document.getElementById("userIdcomment-input");
    userIdcommentForm.value = userId;
    let photoIdcommentForm = document.getElementById("photoIdcomment-input");
    photoIdcommentForm.value = photoId;

    commentForm.onsubmit = handleSubmitComment;

    let commentPlace = document.getElementById("comment");
    photosAPI.get_comments_byId(photoId)
        .then(comments => {
            for (let comment of comments) {
                let html = `<div class= "comment-body">
                                <p>${comment.comment} Commented by <a href= "profile.html?userId=${comment.userId}" class= "user-link">
                                User ${comment.userId} </a> on ${comment.date}</p>
                            </div>`;
                let commentHTML = parseHTML(html);
                commentPlace.appendChild(commentHTML);
            }
        })
        .catch(error => {
            messageRenderer.showErrorMessage(error)
        });
}

function hideActionButtons() {
    let actions_col = document.getElementById("photo-buttons-column");
    if (!sessionManager.isLogged()) {
        actions_col.style.display = "none";
    }
}

function handleDelete(event) {
    let answer = confirm("Do you really want to delete this photo?");
    if (answer) {
        photosAPI.delete(photoId)
            .then(data => window.location.href = "index.html")
            .catch(error => messageRenderer.showErrorMessage(error));
    }
}

function handleEdit(event) {
    window.location.href = "edit_photo.html?photoId=" + photoId;
};

function handleSubmitValoration(event) {
    event.preventDefault();
    let form = event.target;
    let formData = new FormData(form);
    
    usersAPI.userValorates(formData)
        .then(data => window.location.href = "photo_details.html?photoId="+photoId)
        .catch(error => messageRenderer.showErrorMessage(error));
    
}

function handleSubmitComment(event) {
    event.preventDefault();
    let form = event.target;
    let formData = new FormData(form);
    
    photosAPI.createComment(formData)
        .then(data => window.location.href = "photo_details.html?photoId="+photoId)
        .catch(error => messageRenderer.showErrorMessage(error));
    
}


document.addEventListener("DOMContentLoaded", main)
