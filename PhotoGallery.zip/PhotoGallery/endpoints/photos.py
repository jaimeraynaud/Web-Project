from silence.decorators import endpoint

@endpoint(
    route = "/photos",
    method= "GET",
    sql="Select * from Photos ORDER BY date DESC"
)

def get_all():
    pass

###############################################################################

@endpoint(
    route = "/photos/$photoId",
    method= "GET",
    sql="Select * from Photos WHERE photoId = $photoId"
)

def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/photos",
    method="POST",
    sql="INSERT INTO Photos (title, description, url, visibility, userId, category, category2) VALUES ($title, $description, $url, $visibility, $userId, $category, $category2)",
    description="Creates a new photo",
)
def create(title, description, url, visibility, userId, category, category2):
    pass

###############################################################################

@endpoint(
    route="/photos/$photoId",
    method="PUT",
    sql="UPDATE Photos SET title = $title, description = $description, url = $url, visibility = $visibility, category = $category, category2 = $category2 WHERE photoId = $photoId",
    description="Updates an existing photo",
)
def update(title, description, url, visibility, category, category2):
    pass

###############################################################################

@endpoint(
    route="/photos/$photoId",
    method="DELETE",
    sql="DELETE FROM Photos WHERE photoId = $photoId",
    description="Removes a photo",
)
def delete():
    pass

###############################################################################

@endpoint(
    route="/categories",
    method="POST",
    sql="INSERT INTO Categories (category) VALUES ($category)",
    description="Creates a new category",
)
def createCategory(category):
    pass

###############################################################################

@endpoint(
    route = "/categories",
    method= "GET",
    sql="Select * from Categories"
)

def get_allCategories():
    pass

###############################################################################

@endpoint(
    route = "/categories/$categoryId",
    method= "GET",
    sql="SELECT * FROM Photos WHERE category IN (SELECT category FROM Categories WHERE categoryId = $categoryId) OR category2 IN (SELECT category FROM Categories WHERE categoryId = $categoryId)"
)

def get_by_category():
    pass

###############################################################################

@endpoint(
    route = "/valorations/$photoId",
    method= "GET",
    sql="SELECT AVG(valoration) AS jaja FROM Valorations WHERE Valorations.photoId = $photoId"
)

def getValorationById():
    pass

###############################################################################

@endpoint(
    route = "/comments/$photoId",
    method= "GET",
    sql="SELECT * FROM Comments WHERE photoId = $photoId"
)

def get_comments_byId():
    pass

@endpoint(
    route="/comments",
    method="POST",
    sql="INSERT INTO Comments (comment, userId, photoId) VALUES ($comment, $userId, $photoId)",
    description="Creates a new comment",
)
def createComment(comment, userId, photoId):
    pass

###############################################################################

@endpoint(
    route="/photosFriends/$userId",
    method="GET", 
    sql="SELECT * FROM Photos WHERE userId IN (SELECT user2Id FROM UserFollowers WHERE userId = $userId) ORDER BY date DESC"
)
def getAllFriends():
    pass

###############################################################################

@endpoint(
    route="/photosBestRated",
    method="GET", 
    sql="SELECT * from photos WHERE date >= DATE_ADD(CURDATE(), INTERVAL -7 DAY) ORDER BY valoration DESC LIMIT 5"
)
def getBestRatedPhotos():
    pass

###############################################################################

@endpoint(
    route="/photosMostCommented",
    method="GET", 
    sql="SELECT photoId FROM Comments WHERE date >= DATE_ADD(CURDATE(), INTERVAL -7 DAY) GROUP BY photoId ORDER BY COUNT(photoId) DESC LIMIT 5"
)
def getMostCommentedPhotos():
    pass

###############################################################################

@endpoint(
    route="/categoriesMostFrequent",
    method="GET", 
    sql="SELECT category, COUNT(photoId) as c FROM Photos GROUP BY category ORDER BY c DESC LIMIT 5"
)
def getCategoriesMostFrequent():
    pass

###############################################################################

