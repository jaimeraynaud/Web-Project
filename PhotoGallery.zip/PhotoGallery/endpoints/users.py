from silence.decorators import endpoint

@endpoint(
    route="/users/$userId",
    method="GET",
    sql="SELECT * FROM Users WHERE userId = $userId"
)
def get_by_id():
    pass

@endpoint(
    route="/userPhotos/$userId",
    method="GET", 
    sql="SELECT * FROM Photos WHERE userId = $userId"
)
def get_user_photos():
    pass

@endpoint(
    route="/userFollowers/$userId",
    method="GET", 
    sql="SELECT * FROM Users WHERE userId IN (SELECT userId FROM UserFollowers WHERE user2Id = $userId)"
)
def get_user_followers():
    pass

@endpoint(
    route="/userFollowing/$userId",
    method="GET", 
    sql="SELECT * FROM Users WHERE userId IN (SELECT user2Id FROM UserFollowers WHERE userId = $userId)"
)
def get_user_following():
    pass

@endpoint(
    route="/userFollows",
    method="POST",
    sql="INSERT INTO UserFollowers (userId, user2Id) VALUES ($userId, $user2Id)",
    description="Follow a user"
)
def userFollows(userId, user2Id):
    pass

@endpoint(
    route="/userUnfollows/$userId/$user2Id",
    method="DELETE",
    sql="DELETE FROM UserFollowers WHERE (userId = $userId AND user2Id = $user2Id)",
    description="Removes a follow"
)
def userUnfollows(userId, user2Id):
    pass

@endpoint(
    route="/userValorations/$userId",
    method="GET", 
    sql="SELECT * FROM Valorations WHERE userId = $userId"
)
def userValorations():
    pass

@endpoint(
    route="/userValorates",
    method="POST",
    sql="INSERT INTO Valorations (userId, photoId, valoration) VALUES ($userId, $photoId, $valoration)",
    description="Valorate a photo"
)
def userValorates(userId, photoId, valoration):
    pass

@endpoint(
    route="/mostFollowedUsers",
    method="GET", 
    sql="SELECT user2Id, COUNT(USER2Id) as num FROM userfollowers GROUP BY user2Id ORDER BY num DESC"
)
def mostFollowedUsers():
    pass

@endpoint(
    route="/bestRankedUsers",
    method="GET", 
    sql="SELECT userId, AVG(valoration) AS mean FROM photos GROUP BY userId ORDER BY mean DESC"
)
def bestRankedUsers():
    pass


